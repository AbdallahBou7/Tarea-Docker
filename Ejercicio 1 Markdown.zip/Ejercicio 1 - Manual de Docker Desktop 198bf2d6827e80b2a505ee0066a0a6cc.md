# Ejercicio 1 - Manual de Docker Desktop

> Realizado por Abdallah Bouallag y Alejandro Luis
> 

- Accedemos a la pagina del Docker desktop y descargamos el fichero para nuestro sistema operativo

![image.png](image.png)

- Al acabar la descarga, lo ejecutamos y comienza la instalacion

![image.png](image%201.png)

- Se comenzaran a descomprimir los archivos de docker desktop, esto puede tardar unos minutos

![image.png](image%202.png)

- Después de ese tiempo habrá acabado la instalacion y podremos abrir ya docker desktop en nuestro equipo

![image.png](image%203.png)

- En nuestro caso hemos elegido los ajustes recomendados

![image.png](ff124e2a-10a3-4585-8c36-3cea9cd0427b.png)

## GitHub Projects

- Así quedaría el GitHub Project por el momento

![image.png](image%204.png)

![image.png](image%205.png)